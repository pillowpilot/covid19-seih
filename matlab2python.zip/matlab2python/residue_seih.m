function res = residue_seih(x,t1,param,data,init,plotflag,filename)
% residue_seih: funcion a minimizar
% arg_in:
%   x: vector de parametros a determinar
%   t1: fechas en que se va cambiando uno de los parametros
%   param: estructura de los parametros
%   data: datos leidos desde archivos
%   init: fecha inicial y condiciones iniciales
%   plotflag: 0: no grafica las solucion de ode; 1: grafica
%   filename: nombre del archivo, si esta vacio no guarda nada.
% arg_out:
%   res: la diferencia entre la solucion del ode y los datos

% condiciones iniciales
H0 = init.H; D0 = init.D;
Q0 = init.Q;
Rh0 = 0; R0 = 0; I0 = zeros(3,1);
% el primer parametro a determinar es ro que se usa para las condiciones
% iniciales
param.ro = x(1);
% el segundo parametro a determinar es k entre 0 y 1
param.k  = x(2);
% con el valor de ro, se determina las demas condiciones iniciales
ro = param.ro;
I0(1) = ro*Q0; I0(3) = ro*H0;
I0(2) = (I0(1)+I0(3))*param.k/(1-param.k);
E0  = sum(I0)*ro;
y0 = [param.N-E0-sum(I0); E0; I0; Q0; Rh0; H0; R0; D0];

nt1 = size(t1,1);
% beta es un grupo de parametros a determinar colocadas en las fechas
% indicadas en t1
param.beta  = x(3:nt1+2);
% drate es otro grupo de parametros a determinar
param.drate = x(nt1+3:end);

% se monta la matriz
lambda  = [1-(param.k+param.severe); param.k; param.severe];
delta_l = param.delta(1); delta_r = param.delta(2); 
M = zeros(10);
M(1,3:5)   = -param.beta(1) * param.contact;
M(2,2:5)   = [-param.alpha, param.beta(1) * param.contact];
M(3:5,2:5) = [lambda * param.alpha, -diag(param.gamma)];
M(6:8,3:5) = diag(param.gamma);
M(6,6)     = -delta_l;
M(8,8)     = -delta_r;
M(9,[6 8]) = [delta_l (1-param.drate(1))*delta_r];
M(10,8)    = param.drate(1)*delta_r;

% determina que parte de los datos de acumulados infectados se va a usar
delayT = datenum(init.t)-datenum(data.T.Var1(1)) + 1;
% determina que parte de los datos de acumulados fallecidos se va a usar
delayD = datenum(data.D.Var1(1)) - datenum(init.t) + 1;

% tiempo de simulacion
time = data.T.Var1(delayT:end);

% resuelve ODE
[t,y] = ode45(@seih,datenum(time),y0,[],M,param,datenum(t1));
% extrae parte de la solucion de ode
cumI = sum(y(:,[6 8:10]),2); H = y(:,8); D = y(:,10);

% grafica
if plotflag == 1
semilogy(t,cumI,t,H,t,D,...
    datenum(data.T.Var1(delayT:end)),data.T.Var2(delayT:end),'--k',...
    datenum(data.D.Var1),data.D.Var2,'-.k');%,...
%     datenum(data.R.Var1),data.R.Var2,':k',t,param.N-y(:,1));
xlabel('Dias'); ylabel('individuos')
datetick('x', 'ddmmm')
axis([datenum(init.t) datenum(data.T.Var1(end)) 1 3e6]);
legend('I accum','H','deaths','Location','SouthEast')
end

% la diferencia entre la solucion del ode y los datos
if length(t) < length(time)
    res = 100;
else
res = norm(log(cumI)-log(data.T.Var2(delayT:end)),2) ...
    + norm(log(D(delayD:end))-log(data.D.Var2),2);
end

% guarda algunas infos en archivos
if ~isempty(filename)
filerT = fopen(['THDcum_' filename '.dat'],'wt');
nT = length(t);
for i = 1:nT
    fprintf(filerT,'%s %f %f %f\n',time(i),cumI(i),H(i),D(i));
end
fclose(filerT);

filerB = fopen(['rt_' filename '_' num2str(param.k,'%3.1f') '_' num2str(param.ro,'%3.1f') '.dat'],'wt');
nT = size(t1,1);
for i = 1:nT
    rt1 = param.beta(i)*sum(param.contact.*lambda'./param.gamma);
    rtf = param.beta(i)*sum(param.contact([1 3]).*lambda([1 3])'./param.gamma([1 3]));
    fprintf(filerB,'%s %f %f %f %f\n',t1(i,:),...
        cumI(datenum(time)==datenum(t1(i,:))),param.beta(i),rt1,rtf);
end
fclose(filerB);

filerH = fopen(['Hlimit_' filename '.dat'],'wt');
nT = length(param.Hlimit);
C = {'%s ';'%f ';'\n'};
fprintf(filerH,[C{[1 2*ones(1,nT) 3]}],data.T.Var1(1),param.Hlimit);
fprintf(filerH,[C{[1 2*ones(1,nT) 3]}],data.T.Var1(end),param.Hlimit);
fclose(filerH);

filerD = fopen(['drate_' filename '_' num2str(param.k,'%3.1f') '_' num2str(param.ro,'%3.1f') '.dat'],'wt');
datay = init.D;
if datay < 10; datay = 10; end
fprintf(filerD,'%s %f %f %f\n',init.t,datay,...
    param.drate(1)*param.severe*100,param.drate(1)*param.severe/(1-param.k)*100);
nT = length(param.Hlimit);
for i = 2:nT
    datex = interp1(H+1e-10*randn(size(H)),time,param.Hlimit(i));
    datay = D(datenum(time)==round(datenum(datex)));
    fprintf(filerD,'%s %f %f %f\n',datex,datay,...
        param.drate(i)*param.severe*100,param.drate(i)*param.severe/(1-param.k)*100);
end
fclose(filerD);


end

