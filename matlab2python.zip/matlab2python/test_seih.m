clear
% World
% parametros
param.contact = [1 1 0.3];
param.severe  = 0.15;
param.alpha = 1/5;
param.gamma   = 1./[5 14 6];
param.delta = 1./[9 15];
param.N     = 1e8;
param.In    = 0;
param.Hlimit  = [0 10 50 100 500 1000 5000];
% fecha de inicio de la simulacion
init.t = '01/22/2020';
% nombre del archivo
filename = 'world';
% lee datos de acumulados infectados: archivo de 2 columnas (column1: fecha, column2: numero)
data.T = readtable('cum_world.dat');
% lee datos de acumulados fallecidos: archivo de 2 columnas (column1: fecha, column2: numero)
data.D = readtable('dcm_world.dat');
% lee datos de acumulados recuperados: archivo de 2 columnas (column1: fecha, column2: numero)
data.R = readtable('rcm_world.dat');
% condiciones iniciales
init.Q = 6; init.H = 1; init.D = 0;
% fechas en que se va cambiando uno de los parametros
t1 = [init.t; '01/28/2020';'02/10/2020';'03/02/2020';'03/22/2020'];
% valores min y max que se coloca en "ga" para las condiciones iniciales
romin = 2; romax = 4;
% numeros de variables para ga
nn = 2 + size(t1,1) + length(param.Hlimit);
disp(nn);
% cantidad maxima de generaciones para ga
maxGen = 50;

% Italia
% param.contact = [1 1 0.3];
% param.asymp = 0.5;       param.severe  = 0.20;
% param.alpha = 1/5;       param.gamma   = 1./[5 14 6];
% param.delta = 1./[9 15];
% param.N     = 1e8;
% param.In    = 0;         param.Hlimit  = [0 1000 5000 10000];
% init.t = '02/20/2020'; filename = 'it';
% data.T = readtable('data/cum_it.dat');
% data.D = readtable('data/dcm_it.dat');
% data.R = readtable('data/rcm_it.dat');
% init.E = 0; init.I = [0;0;0]; init.R = [0;0]; init.Q = 2; init.H = 1; init.D = 0;
% t1 = [init.t;'03/04/2020';'03/11/2020';'03/18/2020'];
% romin = 2; romax = 20;
% nn = 2 + size(t1,1) + length(param.Hlimit);
% maxGen = 1000;

% Korea
% param.beta    = 0.6;      param.alpha  = 1/5;
% param.contact = [1 0.3];  param.lambda = [0.70 0.30];
% param.gamma   = 1./[5 3]; param.delta  = 1./[9 14];
% param.N       = 1e8;      param.drate  = .04; 
% param.In      = 0;        param.Hlimit = 0;
% init.t = '25-Feb-2020';
% data.T = readtable('data/cum_kr.dat'); init.T = data.T.Var2(data.T.Var1 == init.t);
% data.D = readtable('data/dcm_kr.dat'); init.D = data.D.Var2(data.D.Var1 == init.t);
% data.R = readtable('data/rcm_kr.dat'); init.R = data.R.Var2(data.R.Var1 == init.t);
% t1 = ['01-Mar-2020'; '15-Mar-2020']; %t1 = [];
% x = [2539.70 2246.48 293.11 0.00 0.07 0.41]'; xo=x;
% minf = 100;

% opciones para ga
options = optimoptions(@ga,'Display','iter','MaxGenerations',maxGen);
tic
% funcion a minimizar: "residue_seih"
[x,fval] = ga(@(x)residue_seih(x,t1,param,data,init,0,''),nn,[],[],[],[],...
        [romin;zeros(nn-1,1)],[romax;ones(nn-1,1)],[],options);
toc
% grafica los resultados con los parametros hallados por ga
figure(1); residue_seih(x,t1,param,data,init,1,'');
xo = x;
fprintf('%3.1f\n',fval);
fprintf('%4.2f ',xo');
fprintf('\n');

% halla el promedio del parametro beta: (sum dt_i*beta_i)/(sum dt_i)
betaprom = sum(diff([datenum(t1);now]') .* xo(3:size(t1,1)+2))/(now-datenum(t1(1,:)));
% guarda en un archivo los valores de los parametros hallados por ga
filer = fopen(['data/' filename '_xoxx.dat'],'wt');
fprintf(filer,'%f ',[xo betaprom]);
fprintf(filer,'\n');
fclose(filer);
