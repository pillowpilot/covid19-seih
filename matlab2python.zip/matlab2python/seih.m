function fun = seih(t,y,M,param,t1)
% Lado derecho de la ODE
% t: tiempo
% y: vector de 10 variables
% M: matriz de parametros
% param: parametros
% t1: el mismo t1 que otros archivos
S = y(1); H = y(8);

% busca en que intervalo de t1 se encuentra el tiempo actual t
ind = find(t1<=t,1,'last');
% con eso se obtiene el valor de beta que se va a usar
beta = param.beta(ind);
% modifica partes de la matriz M
M(1,3:5) = -beta * param.contact;
M(2,3:5) =  beta * param.contact;

M(1:2,3:5) = M(1:2,3:5) * (S/param.N);

% busca en que intervalo de Hlimit se encuentra el valor actual de H
ind = find(param.Hlimit<=H,1,'last');
if isempty(ind)
    ind = 1;
end
% con eso se obtiene el valor de drate que se va a usar
drate = param.drate(ind);
% modifica partes de la matriz M
M(9:10,8) = [1-drate; drate] * param.delta(2);

% se obtiene el lado derecho
fun = M * y;
% fun(2:5) = fun(2:5) + [0.5; param.lambda'] * param.In;
